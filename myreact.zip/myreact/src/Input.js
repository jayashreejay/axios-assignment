import React, {useState, useEffect } from 'react'
import axios from 'axios'
import style from "./style.css"

export default function Input (props){
    const [name,updatename] = useState([]);
    const [newname,updatenewname] = useState("");
    
    useEffect(() => {
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((res) =>{
            updatename(res.data)
        })
    },[])

    const changename = (event)=> {
        updatenewname(event.target.value);
    };

const submitname = () =>{
    axios.post("https://jsonplaceholder.typicode.com/posts",{name: newname})
    .then((res) => {
    updatename([...name,{ name : newname, id: res.data.id}])
    })
}

    return(
        <div style={{backgroundColor:"bisque"}}>
    <input type = "text" className="inputfield" onChange ={changename} style={{marginLeft:"28rem", borderWidth:"3px", marginTop:"25px", borderSpacing:"29px", paddingLeft:"8rem"}}></input>
    <button onClick={submitname}  style={{backgroundColor:"lightseagreen",marginLeft:"5px", borderColor:"black" }}>ADD ITEM</button>
    <ul>
    {name.map((item,index) => {
        return (
<h3 style={{paddingLeft:"2rem"}} key={index}><li>{item.name}</li></h3>
        )

    })}
    </ul>
        </div>
    );


}