import React from 'react'
import {Component} from 'react'
import Input from './Input'
import "./style.css"


function Apps() {
  return (
    <div className="App">
    <h1 style={{backgroundColor:"darkcyan",paddingLeft:"32rem",marginBottom:"0px"}}>DIGIKULL STUDENTS</h1>
    <h2 style={{paddingLeft:"36.5rem",backgroundColor:"lightgray",marginTop:"0px",marginBottom:"0px"}}>  HELLO USER  </h2>
     <Input />
     </div>
  );
}

export default Apps;
