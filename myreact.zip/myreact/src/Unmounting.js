import React from 'react'
import style from './Lifecycle.css'



export default class Unmounting extends React.Component{
    constructor(props){
        super(props)
    }


    render (){
        return(
            <div>
               <h2> Unmounting </h2>
              <p> The next phase in the lifecycle is when a component is removed from the DOM, or unmounting as React likes to call it.

React has only one built-in method that gets called when a component is unmounted:</p> 

<li>componentWillUnmount()</li>

<h3>componentWillUnmount()</h3>
<p>The componentWillUnmount method is called when the component is about to be removed from the DOM.</p>
            </div>
        )
    }
}